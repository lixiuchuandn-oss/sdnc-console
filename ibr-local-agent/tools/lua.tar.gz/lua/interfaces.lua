#!/usr/bin/env lua
local json = require("cjson")
CLISH_CMD="/rhos/bin/clish --lock --log -x /rhos/etc/cli/enable-view -w configure-view"

function execute_command(cmd)
    local handle = io.popen(cmd)
    local result = handle:read("*a")
    handle:close()
    if result == "" then
        result = nil
    end
    return result
end
local meta = {
    __call = function(self, op, cur_table, new_table)
        if op == "add" then
            if cur_table ~= nil then
                self.add_interface_all(cur_table)   
            end        
        elseif op == "update" then
            self.update_interface_all(cur_table, new_table)
        
        elseif op == "del" then
            self.del_interface_all(cur_table)
        end
    end
}

interfaces = {}

interfaces.list = { "interfaces_BondEthernet",
    "subinterfaces_BondEthernet",
    "interfaces_TapEthernet",
    "subinterfaces_TapEthernet",
    "interfaces_memif",
    "subinterfaces_memif",
    "interfaces_GigabitEthernet",
    "subinterfaces_GigabitEthernet",
    "interfaces_lo",
    "interfaces_Tunnel",
    "subinterfaces_Tunnel" }


function interfaces.add_interface_all(cur_table)
    for _, v in pairs(interfaces.list) do
        if cur_table[v] then
            for _, v2 in pairs(cur_table[v]) do
                interfaces.add_interface_part(v2)
            end
        end
    end
end

function interfaces.del_interface_all(cur_table)
    for i= #interfaces.list, 1, -1 do
        if cur_table[interfaces.list[i]] then
            for _, v2 in pairs(cur_table[interfaces.list[i]]) do
                interfaces.del_interface_part(v2)
            end
        end
    end
end

function interfaces.update_interface_all(cur_table, new_table)
    for _, v in pairs(interfaces.list) do
        if new_table[v] and not cur_table[v] then
            for _, v2 in pairs(new_table[v]) do
                interfaces.add_interface_part(v2)
            end
        end
        if cur_table[v] and new_table[v] then
            -- add update interface
            for _, v2 in pairs(new_table[v]) do
                local found = false
                for _, v3 in pairs(cur_table[v]) do
                    if v2.name == v3.name then
                        found = true
                        interfaces.compare_interface_part(v3, v2)
                        break
                    end
                end
                if not found then
                    interfaces.add_interface_part(v2)
                end
            end
            -- del interface
            for _, v2 in pairs(cur_table[v]) do
                local found = false
                for _, v3 in pairs(new_table[v]) do
                    if v2.name == v3.name then
                        found = true
                        break
                    end
                end
                if not found then
                    interfaces.del_interface_part(v2)
                end
            end
        end
    end
    for i= #interfaces.list, 1, -1 do
        if cur_table[interfaces.list[i]] and not new_table[interfaces.list[i]] then
            for _, v2 in pairs(cur_table[interfaces.list[i]]) do
                interfaces.del_interface_part(v2)
            end
        end
    end
end

function interfaces.add_interface_part(interface_table)
    if interface_table == nil then
        return
    end
    if interface_table.name then
        interfaces.add_interface(interface_table.name)
    end
    if interface_table.vlan then
        interfaces.add_interface_vlan(interface_table.name, interface_table.vlan)
    end
    if interface_table.vrf then
        interfaces.add_interface_vrf(interface_table.name, interface_table.vrf)
        interfaces.set_interface_vrf_status(interface_table.name, "enable")
    end
    if interface_table.ipv4_static then
        interfaces.add_interface_v4addr(interface_table.name, interface_table.ipv4_static)
    end
    if interface_table.ipv6_static then
        interfaces.add_interface_v6addr(interface_table.name, interface_table.ipv6_static)
    end
    if interface_table.status then
        interfaces.set_interface_status(interface_table.name, interface_table.status)
    end
end

function interfaces.del_interface_part(interface_table)
    if interface_table == nil then
        return
    end
   if string.find(interface_table.name, "GigabitEthernet") and not string.find(interface_table.name, "%.") then
        interfaces.set_interface_status(interface_table.name, "down")
        if interface_table.ipv4_static then
            interfaces.del_interface_v4addr(interface_table.name, interface_table.ipv4_static)
        end
        if interface_table.ipv6_static then
            interfaces.del_interface_v6addr(interface_table.name, interface_table.ipv6_static)
        end
        if interface_table.vrf then
            interfaces.del_interface_vrf(interface_table.name)
        end
        if string.find(interface_table.name, "%.") then
            interfaces.del_interface(interface_table.name)
        end
    else
        interfaces.del_interface(interface_table.name)
    end
end
function interfaces.compare_interface_part(cur_table, new_table)
    if not cur_table then
        return 
    end
    if not new_table then
        return 
    end
    if cur_table.name ~= new_table.name then
        return
    end
    if cur_table.vlan ~= new_table.vlan then
        interfaces.del_interface_vlan(cur_table.name, cur_table.vlan)
        interfaces.add_interface_vlan(cur_table.name, new_table.vlan)
    end
    if cur_table.vrf ~= new_table.vrf then
        interfaces.del_interface_vrf(cur_table.name)
        interfaces.add_interface_vrf(cur_table.name, new_table.vrf)
        interfaces.add_interface_v4addr(cur_table.name, new_table.ipv4_static)
        interfaces.add_interface_v6addr(cur_table.name, new_table.ipv6_static)
        interfaces.set_interface_status(cur_table.name, new_table.status)
    else
        if cur_table.ipv4_static ~= new_table.ipv4_static then
            interfaces.del_interface_v4addr(cur_table.name, cur_table.ipv4_static)
            interfaces.add_interface_v4addr(cur_table.name, new_table.ipv4_static)
        end
        if cur_table.ipv6_static ~= new_table.ipv6_static then
            interfaces.del_interface_v6addr(cur_table.name, cur_table.ipv6_static)
            interfaces.add_interface_v6addr(cur_table.name, new_table.ipv6_static)
        end
        if cur_table.status ~= new_table.status then
            interfaces.set_interface_status(cur_table.name, new_table.status)
        end
    end
end


function interfaces.add_interface(interface_name)
    if interface_name == nil then
        return
    end
    local cmd = string.format("%s -c 'interface %s'", CLISH_CMD, interface_name)
    print(cmd)
    local result = execute_command(cmd)
    return result
end

function interfaces.del_interface(interface_name)
    if interface_name == nil then
        return
    end
    local cmd = string.format("%s -c 'no interface %s'", CLISH_CMD, interface_name)
    print(cmd)
    local result = execute_command(cmd)
    return result
end

function interfaces.add_interface_vlan(interface_name, vlan_id)
    if interface_name == nil or vlan_id == nil then
        return
    end
    local cmd = string.format("%s -c 'interface %s' -c 'dot1q %i'", CLISH_CMD, interface_name, vlan_id)
    print(cmd)
    local result = execute_command(cmd)
    return result
end

function interfaces.del_interface_vlan(interface_name, vlan_id)
    if interface_name == nil or vlan_id == nil then
        return
    end
    local cmd = string.format("%s -c 'interface %s' -c 'no dot1q %i'", CLISH_CMD, interface_name, vlan_id)
    print(cmd)
    local result = execute_command(cmd)
    return result
end

function interfaces.add_interface_vrf(interface_name, vrf_name)
    if interface_name == nil or vrf_name == nil then
        return
    end
    local cmd = string.format("%s -c 'interface %s' -c 'vrf %i'", CLISH_CMD, interface_name, vrf_name)
    print(cmd)
    local result = execute_command(cmd)
    return result
end

function interfaces.del_interface_vrf(interface_name)
    if interface_name == nil then
        return
    end
    local cmd = string.format("%s -c 'interface %s' -c 'no vrf'", CLISH_CMD, interface_name)
    print(cmd)
    local result = execute_command(cmd)
    return result
end

function interfaces.set_interface_vrf_status(interface_name, status)
    if interface_name == nil or status == nil then
        return
    end
    local cmd = ""
    if status == "enable" then
        cmd = string.format("%s -c 'interface %s' -c 'vrf enable'", CLISH_CMD, interface_name)
    else
        cmd = string.format("%s -c 'interface %s' -c 'no vrf enable'", CLISH_CMD, interface_name) 
    end
    print(cmd)
    local result = execute_command(cmd)
    return result
end

function interfaces.add_interface_v4addr(interface_name, v4_addr)
    if interface_name == nil or v4_addr == nil then
        return
    end
    local cmd = string.format("%s -c 'interface %s' -c 'ip address %s'", CLISH_CMD, interface_name, v4_addr)
    print(cmd)
    local result = execute_command(cmd)
    return result
end

function interfaces.del_interface_v4addr(interface_name, v4_addr)
    if interface_name == nil or v4_addr == nil then
        return
    end
    local cmd = string.format("%s -c 'interface %s' -c 'no ip address %s'", CLISH_CMD, interface_name, v4_addr)
    print(cmd)
    local result = execute_command(cmd)
    return result
end

function interfaces.add_interface_v6addr(interface_name, v6_addr)
    if interface_name == nil or v6_addr == nil then
        return
    end
    local cmd = string.format("%s -c 'interface %s' -c 'ipv6 address %s'", CLISH_CMD, interface_name, v6_addr)
    print(cmd)
    local result = execute_command(cmd)
    return result
end

function interfaces.del_interface_v6addr(interface_name, v6_addr)
    if interface_name == nil or v6_addr == nil then
        return
    end
    local cmd = string.format("%s -c 'interface %s' -c 'no ipv6 address %s'", CLISH_CMD, interface_name, v6_addr)
    print(cmd)
    local result = execute_command(cmd)
    return result
end

function interfaces.set_interface_status(interface_name, status)
    if interface_name == nil or status == nil then
        return
    end
    if status == "down" then
        status = "shutdown"
    else
        status = "no shutdown"
    end
    local cmd = string.format("%s -c 'interface %s' -c '%s'", CLISH_CMD, interface_name, status)
    print(cmd)
    local result = execute_command(cmd)
    return result
end

setmetatable(interfaces, meta)

return interfaces
