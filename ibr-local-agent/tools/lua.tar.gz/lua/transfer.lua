#!/usr/bin/env lua
package.path = package.path .. ";/rhos/etc/agent/tools/lua/?.lua"
local json = require("cjson")
local cli = require("cli")

-- 读取文件函数
local function read_file(path)
    local file = io.open(path, "r")
    if not file then
        print("错误：无法打开文件 " .. path)
        return nil
    end
    local content = file:read("*all")
    file:close()
    return content
end
--cli.vrf("cmp_add", data1.vrf, data2.vrf)
--cli.ipv4_routes("cmp_del", data1.ipv4_routes,data2.ipv4_routes)
-- 处理解析后的数据
local function process_data(data1,data2)
    if data1 and data1.bgp then
        table.sort(data1.bgp, function(a, b)
            if not a.vrf and b.vrf then
                return true
            elseif a.vrf and not b.vrf then
                return false
            end
            return false
        end)
    end
    if data2 and data2.bgp then
        table.sort(data2.bgp, function(a, b)
            if not a.vrf and b.vrf then
                return true
            elseif a.vrf and not b.vrf then
                return false
            end
            return false
        end)
    end
    if data1 and not data2 then
        cli.vrf("add", data1.vrf)
        cli.interfaces("add", data1)
        cli.ipv4_routes("add", data1.ipv4_routes)
        cli.ipv6_routes("add", data1.ipv6_routes)
        cli.ip_prefix_list("add", data1.ip_prefix_list)
        cli.segment_routing("add", data1.segment_routing_srv6)
        cli.route_map("add", data1.route_map)
        cli.bgp("add", data1)
    end
    if data2 and data1 then
        cli.vrf("cmp_add", data1.vrf, data2.vrf)
        cli.interfaces("update", data1, data2)
        cli.ipv4_routes("cmp_add", data1.ipv4_routes, data2.ipv4_routes)
        cli.ipv6_routes("cmp_add", data1.ipv6_routes, data2.ipv6_routes)
        cli.ip_prefix_list("cmp_add", data1.ip_prefix_list, data2.ip_prefix_list)
        cli.route_map("cmp_add", data1.route_map, data2.route_map)
        cli.bgp("update", data1, data2)
        cli.route_map("cmp_del", data1.route_map, data2.route_map)
        cli.ip_prefix_list("cmp_del", data1.ip_prefix_list, data2.ip_prefix_list)
        cli.ipv6_routes("cmp_del", data1.ipv6_routes, data2.ipv6_routes)
        cli.ipv4_routes("cmp_del", data1.ipv4_routes, data2.ipv4_routes)
        cli.vrf("cmp_del", data1.vrf, data2.vrf)
    end
end

function main()
    -- 获取文件路径
    local file_path1 = arg[1]
    local file_path2 = arg[2]
    
    if file_path1 then
        content = read_file(file_path1)
    end
    if file_path2 then
        content1 = read_file(file_path2)
    end
    if content then
        data1 = json.decode(content)
    end
    if content1 then
        data2 = json.decode(content1)
    end
    process_data(data1,data2)
end

main()